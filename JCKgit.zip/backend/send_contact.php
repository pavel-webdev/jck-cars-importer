<?php
require_once 'config.php';

// Защита от спама
session_start();

// Проверка времени между запросами (не чаще 1 раза в 10 секунд)
if (isset($_SESSION['last_submit_time']) && (time() - $_SESSION['last_submit_time']) < 10) {
    echo "Пожалуйста, подождите 10 секунд перед отправкой следующей заявки";
    exit;
}

// Защита от ботов - скрытое поле
if (!empty($_POST['website'])) {
    echo "Ошибка отправки формы";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    
    // Валидация имени
    if (empty($name)) {
        echo "Пожалуйста, введите ваше имя";
        exit;
    }
    if (strlen($name) < 2) {
        echo "Имя должно содержать минимум 2 символа";
        exit;
    }
    if (strlen($name) > 50) {
        echo "Имя не должно превышать 50 символов";
        exit;
    }
    if (!preg_match("/^[a-zA-Zа-яА-ЯёЁ\s\-]+$/u", $name)) {
        echo "Имя может содержать только буквы, пробелы и дефисы";
        exit;
    }
    
    // Валидация email
    if (empty($email)) {
        echo "Пожалуйста, введите ваш email";
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Пожалуйста, введите корректный email адрес";
        exit;
    }
    
    // Валидация телефона
    if (empty($phone)) {
        echo "Пожалуйста, введите ваш телефон";
        exit;
    }
    
    // Очищаем телефон от лишних символов и проверяем длину
    $clean_phone = preg_replace('/[^\d]/', '', $phone);
    if (strlen($clean_phone) < 10) {
        echo "Номер телефона должен содержать минимум 10 цифр";
        exit;
    }
    
    // Обновляем время последней отправки
    $_SESSION['last_submit_time'] = time();
    
    // Настройки Telegram бота
    $botToken = "8594694250:AAHcexCSCcuJVoXSF5y3bgfLlQbDVTo_4Y8"; 
    $chatId = "-1003307416810"; 
    
    // Формируем сообщение
    $message = "🚗 *НОВАЯ ЗАЯВКА НА КОНСУЛЬТАЦИЮ*%0A%0A";
    $message .= "👤 *Имя:* " . urlencode($name) . "%0A";
    $message .= "📧 *Email:* " . urlencode($email) . "%0A";
    $message .= "📞 *Телефон:* " . urlencode($phone) . "%0A%0A";
    $message .= "💬 *Запрос:* Консультация по подбору авто%0A";
    $message .= "🕒 *Время:* " . date("d.m.Y H:i:s") . "%0A";
    $message .= "🌐 *Источник:* Главная страница";
    
    // Отправляем в Telegram
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage?chat_id={$chatId}&text={$message}&parse_mode=Markdown";
    
    $response = @file_get_contents($url);
    
    if ($response !== false) {
        $responseData = json_decode($response, true);
        if ($responseData && $responseData['ok']) {
            echo "success";
        } else {
            echo "Ошибка при отправке заявки";
        }
    } else {
        echo "Ошибка при отправке заявки";
    }
} else {
    echo "Неверный метод запроса";
}
?>